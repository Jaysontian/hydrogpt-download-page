/**
 * See How Your AI Usage Impacts the Environment - Shared Energy Calculator Module
 * ================================================================================
 *
 * This module provides shared energy calculation functionality for both
 * content.js (content script) and dashboard.js (dashboard UI).
 *
 * This eliminates code duplication and ensures consistent calculations
 * across all contexts.
 *
 * Implements the EcoLogits methodology from:
 * https://ecologits.ai/0.2/methodology/llm_inference/
 *
 * Note: This file is loaded in both content script and dashboard contexts.
 * - For content scripts: Loaded via manifest.json before content.js
 * - For dashboard: Loaded via dashboard.html
 *
 * @module energy-calculator
 */

// Check if we should use exports (for module context in popup)
// or just define in global scope (for content script context)
const isModuleContext = typeof module !== 'undefined' && module.exports;

/**
 * EcoLogits methodology constants for LLM energy estimation
 * Source: https://ecologits.ai/0.2/methodology/llm_inference/
 */
const ECOLOGITS_CONSTANTS = {
  // Energy model coefficients
  ENERGY_ALPHA: 8.91e-5,    // Energy coefficient (Wh/token/B-params)
  ENERGY_BETA: 1.43e-3,     // Base energy per token (Wh/token)

  // Latency model coefficients
  LATENCY_ALPHA: 8.02e-4,   // Latency coefficient (s/token/B-params)
  LATENCY_BETA: 2.23e-2,    // Base latency per token (s/token)

  // Infrastructure parameters
  PUE: 1.2,                 // Power Usage Effectiveness for data centers
  GPU_MEMORY: 80,           // GPU memory in GB (NVIDIA A100)
  SERVER_POWER_WITHOUT_GPU: 1, // Server power excluding GPUs (kW)
  INSTALLED_GPUS: 8,        // Typical GPUs per server
  GPU_BITS: 4,              // Quantization level (4-bit)

  // Emissions
  WORLD_EMISSION_FACTOR: 0.418 // Global average CO2 emission factor (kgCO2eq/kWh)
};

/**
 * GPT-5 model parameters
 * Based on the latest model configuration
 */
const GPT5_PARAMS = {
  TOTAL_PARAMS: 300e9,        // 300 billion total parameters
  ACTIVE_PARAMS: 60e9,        // 60 billion active parameters (average of 30-90B range)
  ACTIVE_PARAMS_BILLIONS: 60, // Active params in billions (for formula)
  ACTIVATION_RATIO: 0.2,      // 20% activation ratio (average: 60B/300B)
  ACTIVE_PARAMS_MIN: 30e9,    // Minimum active parameters (30 billion)
  ACTIVE_PARAMS_MAX: 90e9     // Maximum active parameters (90 billion)
};

/**
 * Calculates energy usage and CO2 emissions for LLM inference
 *
 * Uses the EcoLogits methodology (academic research)
 *
 * @param {number} outputTokens - Number of tokens in the assistant's response
 * @param {string} [method='community'] - Estimation method (kept for backward compatibility, defaults to 'community')
 * @returns {Object} Energy and emissions data
 * @returns {number} returns.totalEnergy - Total energy consumption (Wh)
 * @returns {number} returns.co2Emissions - CO2 emissions (grams)
 * @returns {number} returns.numGPUs - Number of GPUs required
 * @returns {Object} returns.modelDetails - Additional model details
 *
 * @example
 * // Calculate energy for 100 tokens
 * const result = calculateEnergyAndEmissions(100);
 * console.log(result.totalEnergy); // ~4.15 Wh
 */
function calculateEnergyAndEmissions(outputTokens, method = 'community') {
  const {
    ENERGY_ALPHA,
    ENERGY_BETA,
    LATENCY_ALPHA,
    LATENCY_BETA,
    PUE,
    GPU_MEMORY,
    SERVER_POWER_WITHOUT_GPU,
    INSTALLED_GPUS,
    GPU_BITS,
    WORLD_EMISSION_FACTOR
  } = ECOLOGITS_CONSTANTS;

  // Community estimates using EcoLogits methodology
  // GPT-5 is a Mixture of Experts (MoE) model with 300B total parameters
  const { TOTAL_PARAMS, ACTIVE_PARAMS, ACTIVE_PARAMS_BILLIONS, ACTIVATION_RATIO } = GPT5_PARAMS;

  // Step 1: Calculate energy per token (per GPU)
  // Uses ACTIVE parameters because energy is proportional to compute in MoE models
  // Formula: E = α × P_active + β
  const energyPerToken = ENERGY_ALPHA * ACTIVE_PARAMS_BILLIONS + ENERGY_BETA;

  // Step 2: Calculate GPU memory requirements and number of GPUs needed
  // Uses TOTAL parameters because memory stores the entire model
  // Formula: M_model = 1.2 × P_total × Q / 8 (Q=quantization bits)
  const memoryRequired = 1.2 * TOTAL_PARAMS * GPU_BITS / 8; // in bytes
  const numGPUs = Math.ceil(memoryRequired / (GPU_MEMORY * 1e9)); // = 3 GPUs for GPT-5

  // Step 3: Calculate inference latency
  // Uses ACTIVE parameters because latency depends on compute
  // Formula: ΔT = #tokens × (A × P_active + B)
  const latencyPerToken = LATENCY_ALPHA * ACTIVE_PARAMS_BILLIONS + LATENCY_BETA;
  const totalLatency = outputTokens * latencyPerToken; // in seconds

  // Step 4: Calculate GPU energy consumption
  // Multiply by numGPUs because all GPUs are active during inference
  const gpuEnergy = outputTokens * energyPerToken * numGPUs;

  // Step 5: Calculate server energy excluding GPUs
  // Server components (CPU, memory, networking) also consume power
  // Formula: E_server = ΔT × P_server × (numGPUs / installedGPUs) / 3600 × 1000
  // Division by 3600 converts seconds to hours, multiplication by 1000 converts kW to W
  const serverEnergyWithoutGPU = totalLatency * SERVER_POWER_WITHOUT_GPU * numGPUs / INSTALLED_GPUS / 3600 * 1000;

  // Step 6: Total server energy (GPU + non-GPU components)
  const serverEnergy = serverEnergyWithoutGPU + gpuEnergy;

  // Step 7: Apply Power Usage Effectiveness (PUE)
  // PUE accounts for data center overhead (cooling, power distribution, etc.)
  const totalEnergy = PUE * serverEnergy;

  // Ensure minimum energy value for visibility in UI
  const minEnergy = 0.01;
  const normalizedEnergy = Math.max(totalEnergy, minEnergy);

  // Step 8: Calculate CO2 emissions
  // Using global average emission factor
  const co2Emissions = normalizedEnergy * WORLD_EMISSION_FACTOR;

  return {
    numGPUs,
    totalEnergy: normalizedEnergy,
    co2Emissions,
    modelDetails: {
      totalParams: TOTAL_PARAMS / 1e9,
      activeParams: ACTIVE_PARAMS / 1e9,
      activationRatio: ACTIVATION_RATIO,
      method: 'community'
    }
  };
}

/**
 * Helper function to get energy per token
 * Useful for displaying rate information in UI
 *
 * @returns {number} Energy per token in Wh/token
 */
function getEnergyPerToken() {
  const { ENERGY_ALPHA, ENERGY_BETA } = ECOLOGITS_CONSTANTS;
  const { ACTIVE_PARAMS_BILLIONS } = GPT5_PARAMS;
  return ENERGY_ALPHA * ACTIVE_PARAMS_BILLIONS + ENERGY_BETA;
}

/**
 * Helper function to get the number of GPUs required for GPT-5
 *
 * @returns {number} Number of GPUs required
 */
function getNumGPUs() {
  const { GPU_MEMORY, GPU_BITS } = ECOLOGITS_CONSTANTS;
  const { TOTAL_PARAMS } = GPT5_PARAMS;
  const memoryRequired = 1.2 * TOTAL_PARAMS * GPU_BITS / 8;
  return Math.ceil(memoryRequired / (GPU_MEMORY * 1e9));
}

// Make functions available globally for content scripts
// and as CommonJS exports for Node.js testing
if (typeof window !== 'undefined') {
  // Browser context - make available globally
  window.ECOLOGITS_CONSTANTS = ECOLOGITS_CONSTANTS;
  window.GPT5_PARAMS = GPT5_PARAMS;
  window.calculateEnergyAndEmissions = calculateEnergyAndEmissions;
  window.getEnergyPerToken = getEnergyPerToken;
  window.getNumGPUs = getNumGPUs;
}

// CommonJS exports for Node.js testing
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    ECOLOGITS_CONSTANTS,
    GPT5_PARAMS,
    calculateEnergyAndEmissions,
    getEnergyPerToken,
    getNumGPUs
  };
}

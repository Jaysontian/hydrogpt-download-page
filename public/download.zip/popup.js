/**
 * See How Your AI Usage Impacts the Environment - Popup UI Script
 * ================================================================
 * This script handles the popup UI functionality including loading,
 * displaying usage logs and environmental metrics.
 *
 * Note: energy-calculator.js is loaded before this file via popup.html
 * The calculateEnergyAndEmissions() function is available from window.calculateEnergyAndEmissions
 */

/**
 * Safely access chrome.storage API
 * Returns null if not available
 */
const getChromeStorage = () => {
  try {
    // Check if we're in a proper extension context
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return chrome.storage.local;
    }
  } catch (e) {
    console.error("Error accessing chrome storage API:", e);
  }
  return null;
};

/**
 * One-time cleanup of email-related storage keys (Issue #15)
 * Removes all email collection data from previous versions
 */
function cleanupEmailStorage() {
  const storage = getChromeStorage();
  if (storage) {
    storage.remove([
      'userEmail',
      'emailConsent',
      'emailConsentDate',
      'marketingConsent',
      'marketingConsentDate'
    ], function() {
      console.log('Email storage cleanup completed (Issue #15)');
    });
  }
}

document.addEventListener('DOMContentLoaded', function() {
  try {
    // One-time cleanup: Remove old email-related storage keys (Issue #15)
    cleanupEmailStorage();

    // Set up tab switching (this will work regardless of storage)
    document.getElementById('lifetime-tab').addEventListener('click', function() {
      switchTab('lifetime');
    });

    document.getElementById('today-tab').addEventListener('click', function() {
      switchTab('today');
    });

    // Add resize observer to adjust popup size based on content
    adjustPopupHeight();

    // Initialize with empty data
    updateTodayStats([]);
    updateLifetimeStats([]);

    // Try to load logs, but don't fail if storage is unavailable
    loadLogs();
  } catch(err) {
    console.error("Error initializing popup:", err);
  }
});

/**
 * Adjusts the popup height to fit content without scrolling
 * Uses a safer implementation to avoid ResizeObserver loop errors
 */
function adjustPopupHeight() {
  // Use requestAnimationFrame to avoid ResizeObserver loops
  let rafId = null;
  let lastHeight = 0;
  let resizeObserver = null;
  
  // Function that actually handles resizing, but throttled with rAF
  const processResize = () => {
    rafId = null;
    
    // Get the visible tab content
    const activeTab = document.querySelector('.stats-container.active');
    if (!activeTab) return;
    
    // Get current height
    const currentScrollHeight = document.body.scrollHeight;
    
    // Only process if height actually changed since last check
    if (currentScrollHeight !== lastHeight && currentScrollHeight > window.innerHeight) {
      lastHeight = currentScrollHeight;
      
      // If we made changes, disconnect and delay re-connecting to prevent loops
      if (resizeObserver) {
        resizeObserver.disconnect();
        setTimeout(() => {
          resizeObserver.observe(document.body);
        }, 100);
      }
    }
  };
  
  // Create the observer with throttling pattern
  resizeObserver = new ResizeObserver(() => {
    if (!rafId) {
      rafId = requestAnimationFrame(processResize);
    }
  });
  
  // Start observing
  resizeObserver.observe(document.body);
  
  // Save reference to allow cleanup if needed
  window._popupResizeObserver = resizeObserver;
}

/**
 * Switches between lifetime and today tabs
 * @param {string} tabId - The ID of the tab to switch to ('lifetime' or 'today')
 */
function switchTab(tabId) {
  // Hide all tabs
  document.querySelectorAll('.stats-container').forEach(container => {
    container.classList.remove('active');
  });
  
  // Remove active class from all tab buttons
  document.querySelectorAll('.tab').forEach(tab => {
    tab.classList.remove('active');
  });
  
  // Show the selected tab
  document.getElementById(`${tabId}-stats`).classList.add('active');
  document.getElementById(`${tabId}-tab`).classList.add('active');
  
  // No need for manual resize event with our improved ResizeObserver
}

/**
 * Loads logs from Chrome storage and updates the UI
 * Includes additional error handling and logging
 */
function loadLogs() {
  try {
    // Get storage safely
    const storage = getChromeStorage();
    if (!storage) {
      console.warn('Chrome storage API not available - showing empty stats');
      return; // We already initialized with empty stats
    }
    
    storage.get(['chatgptLogs', 'extensionVersion'], function(result) {
      // Check for chrome.runtime.lastError safely
      const lastError = chrome.runtime && chrome.runtime.lastError;
      if (lastError) {
        console.error('Error loading logs:', lastError);
        // Retry once after a short delay
        setTimeout(() => {
          console.log('Retrying log load after error...');
          tryLoadLogsAgain();
        }, 500);
        return;
      }
      
      const logs = result.chatgptLogs || [];
      const version = result.extensionVersion || 'unknown';
      console.log(`Loaded ${logs.length} logs from storage (extension version: ${version})`);
      
      // Validate logs format
      if (!Array.isArray(logs)) {
        console.error('Invalid logs format in storage!');
        // Initialize with empty array as fallback
        updateTodayStats([]);
        updateLifetimeStats([]);
        
        // Attempt to repair storage
        chrome.storage.local.set({ 
          chatgptLogs: [],
          extensionVersion: chrome.runtime.getManifest().version 
        });
        return;
      }
      
      // Log some details about the logs if any exist
      if (logs.length > 0) {
        console.log('First log:', logs[0]);
        console.log('Last log:', logs[logs.length - 1]);
        
        // Calculate total energy usage
        const totalEnergy = logs.reduce((sum, log) => sum + (log.energyUsage || 0), 0);
        console.log(`Total energy usage in logs: ${totalEnergy.toFixed(2)} Wh`);
        
        // Check for logs with missing energy values
        const logsWithoutEnergy = logs.filter(log => log.energyUsage === undefined || log.energyUsage === null);
        if (logsWithoutEnergy.length > 0) {
          console.warn(`${logsWithoutEnergy.length} logs have missing energy usage values`);
        }
      }
      
      updateTodayStats(logs);
      updateLifetimeStats(logs);
    });
  } catch (e) {
    console.error('Error in loadLogs:', e);
    // Use empty arrays as fallback
    updateTodayStats([]);
    updateLifetimeStats([]);
  }
}

function tryLoadLogsAgain() {
  try {
    // Get storage safely
    const storage = getChromeStorage();
    if (!storage) {
      console.warn('Chrome storage API not available in retry attempt');
      return; // We already initialized with empty stats
    }
    
    storage.get('chatgptLogs', function(result) {
      // Safely handle result
      if (!result) {
        console.warn('No result from storage in retry');
        return;
      }
      
      const logs = Array.isArray(result.chatgptLogs) ? result.chatgptLogs : [];
      console.log(`Retry loaded ${logs.length} logs from storage`);
      
      updateTodayStats(logs);
      updateLifetimeStats(logs);
    });
  } catch (e) {
    console.error('Error in retry loadLogs:', e);
    // Already initialized with empty stats
  }
}

/**
 * Updates the "Today" section with statistics for today
 * @param {Array} logs - Array of conversation log entries
 */
function updateTodayStats(logs) {
  // Get today's date (midnight)
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  // Filter logs for today only
  const todayLogs = logs.filter(log => new Date(log.timestamp) >= today);
  
  // Calculate today's statistics
  let todayMessages = todayLogs.length;
  let todayEnergyUsage = 0;
  
  // Only use actual log data, don't add minimum values
  if (todayLogs.length === 0) {
    todayEnergyUsage = 0;
  } else {
    todayLogs.forEach(log => {
      // Ensure we have at least a minimum energy value
      const logEnergy = log.energyUsage || 0;
      todayEnergyUsage += logEnergy;
    });
    
    // Use actual value, no minimum threshold
    todayEnergyUsage = todayEnergyUsage;
  }
  
  // Update the UI
  document.getElementById('today-messages').textContent = formatNumber(todayMessages);
  document.getElementById('today-energy').textContent = formatNumber(todayEnergyUsage.toFixed(2), true);
}

/**
 * Updates the lifetime statistics section
 * @param {Array} logs - Array of conversation log entries
 */
function updateLifetimeStats(logs) {
  // Calculate lifetime totals
  let totalMessages = logs.length;
  let totalEnergyUsage = 0;
  
  // Only use actual log data, don't add minimum values
  if (logs.length === 0) {
    totalEnergyUsage = 0;
  } else {
    logs.forEach(log => {
      // Ensure we have at least a minimum energy value
      const logEnergy = log.energyUsage || 0;
      totalEnergyUsage += logEnergy;
    });
    
    // Use actual value, no minimum threshold
    totalEnergyUsage = totalEnergyUsage;
  }
  
  // Update the UI
  document.getElementById('lifetime-messages').textContent = formatNumber(totalMessages);
  document.getElementById('lifetime-energy').textContent = formatNumber(totalEnergyUsage.toFixed(2), true);
  
  // Update global scale comparison
  updateGlobalScaleComparison(logs, totalEnergyUsage);
}

/**
 * Updates the global scale comparison section
 * @param {Array} logs - Array of conversation log entries
 * @param {number} totalEnergyUsage - Total lifetime energy usage in Wh
 */
function updateGlobalScaleComparison(logs, totalEnergyUsage) {
  const messageElement = document.getElementById('lifetime-global-scale-message');

  if (!messageElement) {
    console.warn('Global scale message element not found');
    return;
  }

  // Calculate daily average energy usage
  if (logs.length === 0 || totalEnergyUsage <= 0) {
    messageElement.innerHTML = 'Start using ChatGPT to see your global impact!';
    return;
  }

  // Find the date range of logs
  const timestamps = logs.map(log => new Date(log.timestamp).getTime());
  const oldestTimestamp = Math.min(...timestamps);
  const newestTimestamp = Math.max(...timestamps);

  // Calculate number of days (minimum 1 day to avoid division by zero)
  const daysDifference = Math.max(1, Math.ceil((newestTimestamp - oldestTimestamp) / (1000 * 60 * 60 * 24)));

  // Calculate daily average
  const dailyAverageWh = totalEnergyUsage / daysDifference;

  // Get global scale comparison using the global-scale module
  if (typeof window.getGlobalScaleComparison === 'function') {
    const comparison = window.getGlobalScaleComparison(dailyAverageWh);

    if (comparison && comparison.message) {
      // Format the message with bold highlights
      let formattedMessage = comparison.message;

      // Make the daily average bold
      formattedMessage = formattedMessage.replace(
        `${dailyAverageWh.toFixed(2)} Wh`,
        `<strong>${dailyAverageWh.toFixed(2)} Wh</strong>`
      );

      // Make the global consumption bold
      formattedMessage = formattedMessage.replace(
        comparison.formattedGlobalConsumption,
        `<strong>${comparison.formattedGlobalConsumption}</strong>`
      );

      // Make the entity name bold
      formattedMessage = formattedMessage.replace(
        comparison.closestEntity.name,
        `<strong>${comparison.closestEntity.name}</strong>`
      );

      messageElement.innerHTML = formattedMessage;

      console.log('Global scale comparison:', comparison);
    } else {
      messageElement.innerHTML = 'Insufficient data for global comparison.';
    }
  } else {
    console.error('getGlobalScaleComparison function not available. Make sure global-scale.js is loaded.');
    messageElement.innerHTML = 'Global scale comparison unavailable.';
  }
}

/**
 * Formats numbers with commas for better readability
 * For watt-hour values over 1000, uses k format (e.g., 1.4k)
 * @param {number} num - Number to format
 * @param {boolean} isEnergy - Whether this is an energy value (Wh)
 * @returns {string} Formatted number string
 */
function formatNumber(num, isEnergy = false) {
  // Parse the number to ensure we're working with a number
  const value = parseFloat(num);
  
  // For energy values (Wh) over 1000, use k format
  if (isEnergy && value >= 1000) {
    return (value / 1000).toFixed(1) + 'k';
  }
  
  // Otherwise use comma format
  return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * Energy calculation function is now imported from energy-calculator.js
 *
 * ✅ RESOLVED: Issue #14 - Code duplication has been eliminated
 * The energy calculation logic now lives in energy-calculator.js (shared module)
 * and is imported by both content.js and popup.js.
 *
 * This implements the EcoLogits methodology from:
 * https://ecologits.ai/0.2/methodology/llm_inference/
 *
 * See: energy-calculator.js for the complete implementation
 */
// calculateEnergyAndEmissions is imported from energy-calculator.js at the top of this file
